class Expereince{
  final String organisation;
  final String duration;
  final String length;

  Expereince({required this.organisation, required this.duration, required this.length});
}

List<Expereince> experienceList = [
  Expereince(organisation: "PRAIDUX", duration: "2023 - Present", length: "1 yr"),
  Expereince(organisation: "Splenify", duration: "Jan 2023 - June 2024", length: "6 mos"),
  Expereince(organisation: "Fiverr", duration: "2021 - Present", length: "3 yrs"),
  Expereince(organisation: "Artigence", duration: "Feb 2023 - August 2023", length: "7 mos"),
  Expereince(organisation: "Elbyts", duration: "Sep 2020 - 2021", length: "1 yr"),
  ];