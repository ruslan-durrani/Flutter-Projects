// ignore_for_file: use_build_context_synchronously, no_leading_underscores_for_local_identifiers

import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:my_app/Service%20Providers/hotels_page.dart';
import 'package:my_app/Service%20Providers/local_guide.dart';
import 'package:my_app/Service%20Providers/transport_page.dart';
import 'package:my_app/Trip%20Itineraries/NewTrip.dart';
import 'package:my_app/components/Colors.dart';
import 'package:my_app/components/dialogBox.dart';
import 'package:my_app/touristDashboard/friends.dart';
import 'package:my_app/touristDashboard/social.dart';
import 'package:my_app/user_management/login_page.dart';

class HomeScreen extends StatefulWidget {
  final String email;
  const HomeScreen({Key? key, required this.email}) : super(key: key);

  @override
  State<HomeScreen> createState() => _Home();
}

class _Home extends State<HomeScreen> {
  bool newTrip = false;
  int _currentIndex = 0;
  Uint8List? _image;
  String? name;
  String? email;
  List<dynamic>? friends;
  bool editName = false;
  String current = 'home';
  late TextEditingController nameController;

  List<String> imagePaths = [
    "assets/icons/trips/trip_image1.png",
    "assets/icons/trips/trip_image2.png",
    "assets/icons/trips/trip_image3.png",
    "assets/icons/trips/trip_image4.png",
  ];
  Future<Uint8List> getImageFromUrl() async {
    Uint8List? image = _image;
    try {
      Future<String> downloadUrl = FirebaseStorage.instance
          .ref()
          .child("Profile Pics/github profile.JPG")
          .getDownloadURL();
      http.Response response = await http.get(Uri.parse(downloadUrl as String));
      if (response.statusCode == 200) {
        return response.bodyBytes;
      }
    } catch (e) {
      dialogue_box(context, "Error Fetching image");
    }
    throw Null;
  }

  void updateName(String updatedName) async {
    try {
      CollectionReference myCollection =
          await FirebaseFirestore.instance.collection('tourists');
      QuerySnapshot docs =
          await myCollection.where("name", isEqualTo: name).get();
      DocumentReference docRef = myCollection.doc(docs.docs.first.id);
      await docRef.update({'name': updatedName});
      // ignore: use_build_context_synchronously
      showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: const Text('SUCCESS'),
              content: const Text("Name Updated Successfully"),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('OK'))
              ],
            );
          });
    } catch (e) {
      dialogue_box(context, "An error occured while updating the name");
    }
  }

  File? profilePic;
  void uploadPic(XFile image) async {
    try {
      Uint8List fileBytes = await image.readAsBytes();
      File file = File.fromRawPath(fileBytes);
      Reference ref =
          FirebaseStorage.instance.ref("Profile_Pics").child("${widget.email}");
      TaskSnapshot task = await ref.putFile(file);
      String downloadurl = await task.ref.getDownloadURL();
      print(downloadurl);
    } catch (e) {
      dialogue_box(context, e.toString());
      print(e.toString());
    }

    //   UploadTask uploadTask = FirebaseStorage.instance
    //       .ref()
    //       .child("profilepictures")
    //       .child(const Uuid().v1())
    //       .putFile(profilePic!);
    //   print(docid);
    //   TaskSnapshot taskSnapshot = await uploadTask;
    //   String downloadUrl = await taskSnapshot.ref.getDownloadURL();
    //   await FirebaseFirestore.instance
    //       .collection("tourists")
    //       .doc(docid)
    //       .update({"profilepic": downloadUrl});
    //   await FirebaseFirestore.instance
    //       .collection("tourists")
    //       .doc(docid)
    //       .update({"profilepic": "helllo"});
  }

  void uploadImage() async {
    try {
      final ImagePicker _imgPicker = ImagePicker();
      XFile? _file = await _imgPicker.pickImage(source: ImageSource.gallery);
      if (_file != null) {
        Uint8List img = await _file.readAsBytes();
        setState(() {
          _image = img;
        });
        uploadPic(_file);
      } else {
        print("File is null");
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    // ignore: prefer_const_constructors
    return Scaffold(
      backgroundColor: backgroundColor(),
      body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection("tourists")
              .where('email', isEqualTo: widget.email)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.active) {
              if (snapshot.hasData && snapshot.data != null) {
                Map<String, dynamic> userMap =
                    snapshot.data!.docs.first.data() as Map<String, dynamic>;

                name = userMap["name"];
                email = userMap["email"];
                friends = userMap['friends'];
                nameController = TextEditingController(text: name);
                return IndexedStack(
                  index: _currentIndex,
                  children: [
                    // Home Page
                    Center(
                      child: Column(children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              right: 0, left: 0, top: 10, bottom: 0),
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 10, left: 0, right: 10, bottom: 20),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  width: 400,
                                  height: 80,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5.0),
                                      color: AppBarBackground(),
                                      shape: BoxShape.rectangle),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Hello ${userMap['name']}",
                                        style: TextStyle(
                                          color: button1(),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 25,
                                        ),
                                      ),
                                      Stack(children: [
                                        _image != null
                                            ? CircleAvatar(
                                                radius: 35,
                                                backgroundImage:
                                                    MemoryImage(_image!),
                                              )
                                            : const CircleAvatar(
                                                radius: 35,
                                                backgroundImage: NetworkImage(
                                                    'https://static.vecteezy.com/system/resources/thumbnails/005/544/718/small/profile-icon-design-free-vector.jpg')),
                                        Positioned(
                                            bottom: -12,
                                            left: 35,
                                            child: IconButton(
                                                color: Colors.black,
                                                icon: const Icon(
                                                    Icons.add_a_photo_rounded),
                                                onPressed: uploadImage)),
                                      ])
                                    ],
                                  ),
                                ),
                              ),
                              // Padding(padding: EdgeInsets.symmetric(vertical:10),
                              // child: ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 10),
                                child: TextFormField(
                                    decoration: InputDecoration(
                                        prefixIcon: Icon(
                                          Icons.search,
                                          size: 25,
                                          color: TextFieldBackground(),
                                        ),
                                        disabledBorder:
                                            const OutlineInputBorder(
                                                borderSide: BorderSide.none,
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10))),
                                        enabledBorder: const OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10))),
                                        labelText:
                                            'Search country,city or any place',
                                        labelStyle: TextStyle(
                                          color: button1(),
                                          fontSize: 16,
                                          fontStyle: FontStyle.italic,
                                        ),
                                        border: const OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white)),
                              )
                            ],
                          ),
                        ),
                        Container(
                            margin: const EdgeInsets.symmetric(vertical: 10),
                            width: 500,
                            height: 70,
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                backgroundColor: button1(),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                padding: const EdgeInsets.all(16.0),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text(
                                    "Start a Trip",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 22),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => NewTrip(
                                                    createdBy: widget.email,
                                                  )));
                                    },
                                    icon: const Icon(
                                      Icons.arrow_circle_right_outlined,
                                      size: 40,
                                      color: Colors.white,
                                    ),
                                  )
                                ],
                              ),
                            )),
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 10, right: 20, left: 20),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 30, top: 10),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    Hotels()));
                                      },
                                      style: ElevatedButton.styleFrom(
                                        fixedSize: const Size(130, 120),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12.0),
                                        ),
                                        padding: const EdgeInsets.all(16.0),
                                        backgroundColor:
                                            button1(), // Change the button color as needed
                                      ),
                                      child: const Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons
                                                .home_outlined, // Replace this with the desired icon
                                            size: 50.0,
                                            color: Colors
                                                .white, // Change the icon color as needed
                                          ),
                                          SizedBox(height: 8.0),
                                          Text(
                                            'Hotels',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize: 24.0,
                                              color: Colors
                                                  .white, // Change the text color as needed
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: 10, right: 10),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    Transport()));
                                      },
                                      style: ElevatedButton.styleFrom(
                                        fixedSize: const Size(130, 120),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12.0),
                                        ),
                                        padding: const EdgeInsets.all(16.0),
                                        backgroundColor:
                                            button1(), // Change the button color as needed
                                      ),
                                      child: const Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.car_rental_outlined,
                                            size: 50.0,
                                            color: Colors
                                                .white, // Change the icon color as needed
                                          ),
                                          SizedBox(height: 8.0),
                                          Text(
                                            'Transport',
                                            style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize: 19.0,
                                              color: Colors
                                                  .white, // Change the text color as needed
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(width: 100, height: 30),
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LocalGuide()));
                                },
                                style: ElevatedButton.styleFrom(
                                  fixedSize: const Size(180, 100),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  padding: const EdgeInsets.all(16.0),
                                  backgroundColor:
                                      button1(), // Change the button color as needed
                                ),
                                child: const Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.tour_outlined,
                                      size: 50.0,
                                      color: Colors
                                          .white, // Change the icon color as needed
                                    ),
                                    SizedBox(height: 2.0),
                                    Text(
                                      'Local Guides',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 22.0,
                                        color: Colors
                                            .white, // Change the text color as needed
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, right: 10, top: 10),
                          child: Column(
                            children: [
                              Text("Popular Places",
                                  style: TextStyle(
                                      color: button1(),
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                              SizedBox(
                                width: 250,
                                height: 150,
                                child: ListView.builder(
                                  itemCount: imagePaths.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Container(
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        image: DecorationImage(
                                          image: AssetImage(imagePaths[index]),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      width:
                                          100.0, // Adjust the width as needed
                                      margin: const EdgeInsets.all(8.0),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        )
                      ]),
                    ),
                    const Center(
                      child: Text("Groups"),
                    ),
                    const Center(
                      child: Text("Groups"),
                    ),
                    Center(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text(
                          "My Trips",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 24,
                              fontWeight: FontWeight.bold),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 20),
                                child: Image.asset(
                                  'assets/icons/trips/trip_image1.png',
                                  width: 150,
                                  height: 160,
                                ),
                              ),
                              Image.asset(
                                'assets/icons/trips/trip_image2.png',
                                width: 150,
                                height: 160,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 20),
                                child: Image.asset(
                                  'assets/icons/trips/trip_image3.png',
                                  width: 150,
                                  height: 160,
                                ),
                              ),
                              Image.asset(
                                'assets/icons/trips/trip_image4.png',
                                width: 150,
                                height: 160,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 20),
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      const Color.fromRGBO(16, 136, 174, 1.0),
                                  fixedSize: const Size(230, 50)),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => NewTrip(
                                              createdBy: widget.email,
                                            )));
                              },
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.add,
                                    color: Colors.white,
                                    size: 24.0,
                                  ),
                                  Text(
                                    '   Create New Trip',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                    ),
                                  )
                                ],
                              )),
                        ),
                      ],
                    )),
                    Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const SizedBox(width: 400, height: 30),
                          Stack(children: [
                            _image != null
                                ? CircleAvatar(
                                    radius: 35,
                                    backgroundImage: MemoryImage(_image!),
                                  )
                                : const CircleAvatar(
                                    radius: 35,
                                    backgroundImage: NetworkImage(
                                        'https://static.vecteezy.com/system/resources/thumbnails/005/544/718/small/profile-icon-design-free-vector.jpg')),
                            Positioned(
                                bottom: -12,
                                left: 35,
                                child: IconButton(
                                    color: Colors.black,
                                    icon: const Icon(Icons.add_a_photo_rounded),
                                    onPressed: uploadImage)),
                          ]),
                          const SizedBox(width: 400, height: 10),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: name!.length * 8 + 60,
                              alignment: Alignment.center,
                              child: TextField(
                                onTap: () {
                                  setState(() {
                                    editName = true;
                                  });
                                },
                                onTapOutside: (text) {
                                  setState(() {
                                    editName = false;
                                  });
                                  if (name != nameController.text) {
                                    updateName(nameController.text);
                                  }
                                },
                                readOnly: !editName,
                                autofocus: editName,
                                controller: nameController,
                                // Allow the TextField to expand vertically based on content
                                decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    suffixIcon: Icon(Icons.edit)),
                              ),
                            ),
                          ),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {},
                              icon: const Icon(
                                Icons.email,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: Text(userMap["email"],
                                  style: const TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {},
                              icon: const Icon(
                                Icons.phone,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: Text(userMap["mobile number"],
                                  style: const TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {},
                              icon: const Icon(
                                Icons.pending_actions_outlined,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: const Text("My Trips",
                                  style: TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {},
                              icon: const Icon(
                                Icons.payment_rounded,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: const Text("Payments",
                                  style: TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {},
                              icon: const Icon(
                                Icons.book_online_outlined,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: const Text("My Bookings",
                                  style: TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {},
                              icon: const Icon(
                                Icons.monochrome_photos_outlined,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: const Text("Posts",
                                  style: TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                          const SizedBox(width: 400, height: 15),
                          TextButton.icon(
                              style: ButtonStyle(
                                alignment: Alignment.centerLeft,
                                fixedSize: MaterialStateProperty.all<Size>(
                                    const Size(300, 50.0)),
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Colors.transparent),
                                shape:
                                    MaterialStateProperty.all<OutlinedBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        10.0), // Adjust the radius as needed
                                    side: const BorderSide(
                                        color: Color.fromRGBO(48, 55, 72,
                                            1.00)), // Set the border color
                                  ),
                                ),
                              ),
                              onPressed: () {
                                Navigator.popUntil(
                                    context, (route) => route.isFirst);
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const LoginPage()));
                              },
                              icon: const Icon(
                                Icons.logout,
                                color: Colors.black,
                                size: 33,
                              ),
                              label: const Text("Logout",
                                  style: TextStyle(
                                      color: Color.fromRGBO(48, 55, 72, 1.0),
                                      fontSize: 20,
                                      overflow: TextOverflow.clip))),
                        ],
                      ),
                    ),
                  ],
                );
              } else {
                return const Center(
                  child: CircularProgressIndicator(
                    backgroundColor: Colors.lightBlue,
                  ),
                );
              }
            } else {
              return const Center(
                child: CircularProgressIndicator(
                    backgroundColor: Colors.lightBlue),
              );
            }
          }),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined,
                color: _currentIndex == 0 ? AppBarBackground() : button1()),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.south_america,
                color: _currentIndex == 1 ? AppBarBackground() : button1()),
            label: 'Social',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.groups_2_rounded,
                color: _currentIndex == 2 ? AppBarBackground() : button1()),
            label: 'Friends',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list_alt,
                color: _currentIndex == 3 ? AppBarBackground() : button1()),
            label: 'Trips',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_pin,
                color: _currentIndex == 4 ? AppBarBackground() : button1()),
            label: 'Profile',
          ),
        ],
        backgroundColor: const Color.fromRGBO(0, 0, 0, 1),
        selectedItemColor: backgroundColor(),
        unselectedItemColor: button1(),
        selectedFontSize: 18,
        unselectedFontSize: 16,
        showUnselectedLabels: true,
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            if (index == 1) {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Social()));
            } else if (index == 2) {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          Friends(name: name!, email: widget.email)));
            } else {
              _currentIndex = index;
            }
          });
        },
      ),
    );
  }
}
