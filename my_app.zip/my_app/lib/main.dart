// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/material.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:my_app/firebase_options.dart';
// import 'package:my_app/user_management/login_page.dart';
// import 'package:my_app/user_management/signup_page.dart';

// Future<void> main() async {
// // Adding Widget Bindings
//   WidgetsFlutterBinding.ensureInitialized();

// //GetX Local Storage
//   await GetStorage.init();

//   // FlutterNativeSplash.preserve(widgetsBinding: wb);

// // Initializing FireBase

//   await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

//   User? user = FirebaseAuth.instance.currentUser;
//   await user!.reload();
//   UserMetadata metadata = user.metadata;

//   runApp(const Screen(
//     user: metadata,
//   ));
// }

// class Screen extends StatelessWidget {
//   final UserMetadata user;
//   const Screen({super.key, required this.user});
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//         theme: ThemeData(
//           textTheme: GoogleFonts
//               .aBeeZeeTextTheme(), // Apply Poppins font to the entire theme
//         ),
//         debugShowCheckedModeBanner: false,
//         home: isFirstTime ? SignUpPage() : LoginPage());
//   }
// }
//         // home: (FirebaseAuth.instance.currentUser != null)
//         //     ? const LoginPage()
//         //     : const SignUpPage(),
//         // TripScreen(tripName: 'Winter Trip')
//         // const NewTrip(createdBy: "sherry", friends: [
//         //   'friends',
//         //   'hello',
//         //   'lets check',
//         //   "hii",
//         //   'feg',
//         //   'fgfd',
//         //   'sgrsr',
//         //   'grgr',
//         //   'erge'
//         // ])

//         // home: const Scaffold(
//         //     backgroundColor: Colors.blue,
//         //     body: Center(
//         //       child: CircularProgressIndicator(
//         //         color: Colors.white,
//         //       ),
//         //     ))

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:my_app/firebase_options.dart';
import 'package:my_app/user_management/signup_page.dart';
import 'package:my_app/user_management/login_page.dart';

Future<void> main() async {
  // Initialize Firebase
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Initialize GetStorage for local storage
  await GetStorage.init();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      // Check if it's the user's first sign-in
      future: isFirstSignIn(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          // Show loading indicator while checking first sign-in
          return const MaterialApp(
            home: Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            ),
          );
        } else {
          if (snapshot.hasError) {
            // Show error message if checking fails
            return const MaterialApp(
              home: Scaffold(
                body: Center(
                  child: Text('Error checking first sign-in'),
                ),
              ),
            );
          } else {
            // Determine which page to show based on first sign-in status
            bool isFirstTime = snapshot.data as bool;
            return GetMaterialApp(
                theme: ThemeData(
                  textTheme: GoogleFonts.aBeeZeeTextTheme(),
                ),
                debugShowCheckedModeBanner: false,
                home: 
                isFirstTime ? const SignUpPage() : const LoginPage(),
                // HomeScreen(email: "faiq12@gmail.com")
                );
          }
        }
      },
    );
  }

  // Method to check if it's the user's first sign-in
  Future<bool> isFirstSignIn() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await user.reload();
      UserMetadata metadata = user.metadata;
      return metadata.creationTime == metadata.lastSignInTime;
    }
    return false; // Return false if user is not signed in
  }
}
