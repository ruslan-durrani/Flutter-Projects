package com.praidux.lost_get

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
