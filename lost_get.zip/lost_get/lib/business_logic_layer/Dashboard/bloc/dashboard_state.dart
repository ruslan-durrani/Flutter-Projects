part of 'dashboard_bloc.dart';

class DashboardState {
  final int index;

  DashboardState({this.index = 0});
}
