part of 'onboard_bloc.dart';

abstract class OnboardEvent {}

class ChangePageDotIndicatorEvent extends OnboardEvent {}

class GetStartedButtonClickedEvent extends OnboardEvent {}
