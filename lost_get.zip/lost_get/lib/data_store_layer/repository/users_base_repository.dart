abstract class BaseUsersRepository {
  // Stream<List<UserProfile>> getAllUserData();
}
